const hamMenu = document.querySelector(".header__toggle-menu");
const offScreenMenu = document.querySelector(".off__screen-menu");
const closeMenu = document.getElementById("close-menu");

// Otwórz menu
hamMenu.addEventListener("click", ()=> {
    hamMenu.classList.toggle("active");
    offScreenMenu.classList.toggle("active");
});

// Zamknij menu
closeMenu.addEventListener("click", ()=> {
    hamMenu.classList.remove("active");
    offScreenMenu.classList.remove("active");
});

// Zamknij menu po kliknięciu w links
const menuLinks = offScreenMenu.querySelectorAll("a");
menuLinks.forEach((link)=> {
    link.addEventListener("click", ()=> {
        hamMenu.classList.remove("active");
        offScreenMenu.classList.remove("active");
    });
});